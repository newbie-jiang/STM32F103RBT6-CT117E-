#include "key.h"
#include "led.h"
#include "lcd.h"
#include "seg.h"
#include "adc.h"
#include "usart.h"


unsigned char ucLed = 1;
unsigned char ucAkey_Long;
unsigned long ulTick_ms, ulAkey_Time;
unsigned int key_number;//LCD��ʾ
unsigned char  pucStr[21];
unsigned char ucDot;  //С����
int seg[3]={17,17,17};




void LCD_Proc(void);
void AKEY_Proc(void);
void ledAll_turn (void);
void seg_left(void);

int main(void)
{
  
 
  SysTick_Config(72000);			// ��ʱ1ms(HCLK = 72MHz)
  LED_Init();
	
	STM3210B_LCD_Init();
  LCD_Clear(Blue);
  LCD_SetBackColor(Blue);
  LCD_SetTextColor(White);
	ADC1_Init_AKEY();
  SEG_Init();
	
	
  
	
	
  while(1)
  {
	 AKEY_Proc();
   LCD_Proc();
	 SEG_Disp(seg[2],seg[1],seg[0],ucDot);	
	}
}
unsigned char ucAkey_Val;
int jishu=0;

void AKEY_Proc(void)
{
  ucAkey_Val =  AKEY_Read();
  if(ucAkey_Val != ucAkey_Long)
   {
    ucAkey_Long = ucAkey_Val;
    ulAkey_Time = ulTick_ms;
	 }
  else
    ucAkey_Val = 0;
  if(ucAkey_Val)
  {
   key_number=ucAkey_Val;
	 ledAll_turn();
	 seg_left();
	}
	
	
}


//�������ܣ��������ֵÿ��һ������һλ
void seg_left(void)
{
	ucDot++;
	if(seg[0])
	 {
		seg[2]=seg[1];
		seg[1]=seg[0]; 
	 }
	  seg[0]=ucAkey_Val;
}



//�������ܣ�LCD����ʾ����ֵ
void LCD_Proc(void)
{ //ע��ʹ��sprintf��Ҫ��"usart.h"
  sprintf((char*)pucStr, "  key number:%02d     ", key_number);
  LCD_DisplayStringLine(Line4, pucStr);
}


//�������ܣ���������LED��ת
int ledall[8]={1 ,2 ,4, 8, 16, 32, 64 ,128  };
int i;
void ledAll_turn (void)
{
	i=ucAkey_Val;
if(ucLed == ledall[i-1])
		ucLed=0;
else
	ucLed = ledall[i-1];
  LED_Disp(ucLed);
}



// SysTick�жϴ�������
void SysTick_Handler(void)
{
  ulTick_ms++;
}





