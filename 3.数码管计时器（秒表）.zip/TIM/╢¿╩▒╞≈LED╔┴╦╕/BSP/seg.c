#include "seg.h"



void SEG_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void SEG_Disp(unsigned char ucData1, unsigned char ucData2,
  unsigned char ucData3, unsigned char ucDot)
{
  unsigned char i;
//  unsigned char code[17]={0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07,
//    0x7f, 0x6f, 0x77, 0x7c, 0x39, 0x5e, 0x79, 0x71, 0x00}; //ֱ�Ӷ������0123����15
	
  unsigned char code[17]={0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07,0x7f, 0x6f};
	//0x77, 0x7c, 0x39, 0x5e, 0x79, 0x71, 0x00}; 
	
  unsigned long ulData = (code[ucData3] << 16) + (code[ucData2] << 8)
    + code[ucData1];

  ulData += (ucDot&1)<<23; //��λ
  ulData += (ucDot&2)<<14; //ʮλ
  ulData += (ucDot&4)<<5;  //��λ
	/*
	SER(������������)--PA1 
  SCK(��λʱ��)    --PA3 
  RCK(������棩   --PA2
	*/


  for(i=0; i<24; i++)
  {
    if(ulData & 0x800000)						//0x800000   24  ������λ
      GPIO_SetBits(GPIOA, GPIO_Pin_1);			// PA1(SER)=1
    else
      GPIO_ResetBits(GPIOA, GPIO_Pin_1);		// PA1(SER)=0
    ulData <<= 1;
    GPIO_SetBits(GPIOA, GPIO_Pin_3);			// PA3(SCK)=1
    GPIO_ResetBits(GPIOA, GPIO_Pin_3);			// PA3(SCK)=0
  }
  GPIO_SetBits(GPIOA, GPIO_Pin_2);				// PA2(RCK)=1
  GPIO_ResetBits(GPIOA, GPIO_Pin_2);			// PA2(RCK)=0
}

