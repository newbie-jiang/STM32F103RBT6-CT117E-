#include "key.h"
#include "led.h"
#include "lcd.h"
#include "usart.h"
#include "adc.h"

unsigned int uiAdc_Val;
unsigned char ucHeight, ucLevel, ucLevel1;
unsigned char ucState, pucStr[21], pucTh[3], pucRcv[1];
unsigned char ucLed, ucLd2, ucLd3,ucLd4, ucNum = 10;
unsigned char ucSec, ucSec1, ucKey_Long;
unsigned long ulTick_ms;
int delay=1000;
unsigned int  pwm=5;
unsigned int  pwm_lcd=50;

void KEY_Proc(void);
void LCD_Proc(void);
void ADC_Proc(void);
void UART_Proc(void);

int main(void)
{
  SysTick_Config(72000);
 

  STM3210B_LCD_Init();
  LCD_Clear(Blue);
  LCD_SetBackColor(Blue);
  LCD_SetTextColor(White);
  KEY_Init();
  LED_Init();
  USART2_Init(9600);
 
  ADC1_Init();
	pwm_lcd=pwm*10;
 
  while(1)
  {
    KEY_Proc();
    LCD_Proc();
   
  }
}

void KEY_Proc(void)
{
  unsigned char ucKey_Val;

  ucKey_Val = KEY_Scan();
  if(ucKey_Val != ucKey_Long)
    ucKey_Long = ucKey_Val;
  else
    ucKey_Val = 0;

  switch(ucKey_Val)
  {
    case 1:												// B1: ���ü�
      if(!ucState)
        ucState = 1;
			 else
      {
       ucState =0;
       }
      break;
    case 2:												// B2:�Ӱ���
      if(!ucState)
       delay+=100;
			if(delay>2000)
				delay=1000;
			if(ucState)
			{
				pwm++;
				if(pwm>10)
				pwm=5;	
			}
      break;
    case 3:												// B3: ������
      if(!ucState)
       delay-=100;
			if(delay<500)
				delay=1000;
			if(ucState)
			{
				pwm--;
				if(pwm<10)
				pwm=5;	
			} 
      break;
   
  }
}

void LCD_Proc(void)
{
  float temp;

  if(!ucState)										
  {
   sprintf((char*)pucStr, " LED_Delay: %1uMs        ", delay);
   LCD_DisplayStringLine(Line4, pucStr);
	 ucLd2=1;
	if(ucLd2==1)ucLd3=0;
  }
  else													
  {
   sprintf((char*)pucStr, "  PWM:%02u  ", pwm_lcd);
   if(ucState == 3) LCD_SetBackColor(Red);
   LCD_DisplayStringLine(Line4, pucStr);
   LCD_SetBackColor(Blue);
	
		 ucLd3=1;
	 if(ucLd3==1)ucLd2=0;
	
  }
}


void pwm_(void)
{
	
	




}


  	

unsigned int count=0;
void TIM2_IRQHandler(void) 
{  
   	
	ucLd2=0;
	count++;//���жϴ���
	 if(count==11)count=1;//��ֹ������ͷ��
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) != RESET)
	{	
	  if(count%10>=pwm)//i���ı�ռ�ձ�ֵ������iΪ����������ռ�ձ�һֱ�仯
		ucLed =0xff;//�ߵ�ƽ
		else
		ucLed =0;
	  TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
		
   }
}



 void TIM2_NVIC(void)
 {
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����жϷ���
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;//����TIM2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//��ռ���ȼ�Ϊ0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;//��Ӧ���ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ж�Դ
  NVIC_Init(&NVIC_InitStructure);
 }



 void TIM2_Init(void)
{

  TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  TIM_TimeBaseInitStruct.TIM_Prescaler = 400-1;//Ԥ��Ƶϵ��
  TIM_TimeBaseInitStruct.TIM_Period = 36000-1;//�Զ����ؼ�������ֵ  
  TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;//����Ϊ���ϼ�����ʽ
  TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;//ʱ�ӷ�Ƶϵ��
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);
  TIM_ClearFlag(TIM2,TIM_FLAG_Update);//����ж�
  TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);//ʹ��TIM2�ĸ����ж�
  TIM_Cmd(TIM2, ENABLE);//ʹ��TIM2��ʱ��
}  




// SysTick�жϴ�������
void SysTick_Handler(void)
{
  ulTick_ms++;
if(ulTick_ms%delay == 0)
  {
    ucSec++;
  }

if(ucLd2)												// �ȼ��ı�
  {
    if(ulTick_ms%delay == 0)
    {
		ulTick_ms = 0;
    ucLed <<= 1;
    if(ucLed == 0) ucLed = 1;
     }
	}

//  if(ucLd3)										   // ���ڲ�ѯ
//  {
//    if(ulTick_ms%1000 == 0)
//    {
//     ulTick_ms = 0;
//     ucLed >>= 1;
//    if(ucLed == 0) ucLed = 0x80;
//    }
//   }
  LED_Disp(ucLed);
}

