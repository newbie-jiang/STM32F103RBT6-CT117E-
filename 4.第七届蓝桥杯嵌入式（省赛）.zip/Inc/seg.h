#include "stm32f10x.h"

void SEG_Init(void);
void SEG_Disp(unsigned char ucData1, unsigned char ucData2,
  unsigned char ucData3, unsigned char ucDot);
