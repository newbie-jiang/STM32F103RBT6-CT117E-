#include "adc.h"

void ADC1_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  ADC_InitTypeDef ADC_InitStruct;
  // ??GPIOB?ADC1   ����ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  // PB0-IN8ģ������
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStruct);
  // ��ʼ��ADC1 
  ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;  
  ADC_InitStruct.ADC_ScanConvMode = DISABLE;
  ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStruct.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStruct);
  // ͨ��8
  ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 1,
    ADC_SampleTime_1Cycles5);    
  // ͨ��16
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_16, 1,
    ADC_SampleTime_239Cycles5);
  ADC_TempSensorVrefintCmd(ENABLE);	
  ADC_AutoInjectedConvCmd(ADC1, ENABLE);
  // ����ADC1
  ADC_Cmd(ADC1, ENABLE);   
  // У׼ADC1
  ADC_StartCalibration(ADC1);
  while(ADC_GetCalibrationStatus(ADC1));
}

void ADC1_Init_AKEY(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  ADC_InitTypeDef ADC_InitStruct;
  // ����GPIOA��ADC1ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
  // PA5-IN5ģ������
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
  // ��ʼ��ADC1
  ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;  
  ADC_InitStruct.ADC_ScanConvMode = DISABLE;
  ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStruct.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStruct);
  // ����ͨ��5
  ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 1,
    ADC_SampleTime_1Cycles5);    
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_4, 1,
    ADC_SampleTime_1Cycles5);						// ????4
  ADC_AutoInjectedConvCmd(ADC1, ENABLE);				// ????????
// ����ADC1
  ADC_Cmd(ADC1, ENABLE);   
  // У׼ADC1
  ADC_StartCalibration(ADC1);
  while(ADC_GetCalibrationStatus(ADC1));
}

unsigned int ADC1_Conv(void)
{
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
  return ADC_GetConversionValue(ADC1);
}

unsigned int ADC1_InjeConv(void)
{
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC));
  ADC_ClearFlag(ADC1, ADC_FLAG_JEOC);
  return ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
}
#ifdef EXTEND
unsigned char AKEY_Read(void)
{
  unsigned char ucAkey_Val = 0;
  unsigned int  uiAdc_Val = ADC1_Conv();

  if(uiAdc_Val < 0xf00)				// ��������
  { 
    Delay_AKEY(100);
    uiAdc_Val = ADC1_Conv();
    if(uiAdc_Val < 0xf00)
    { 
      if(uiAdc_Val > 0xa00)
        ucAkey_Val = 8;
      else if(uiAdc_Val > 0x800)
        ucAkey_Val = 7;
      else if(uiAdc_Val > 0x680)
        ucAkey_Val = 6;
      else if(uiAdc_Val > 0x500)
        ucAkey_Val = 5;
      else if(uiAdc_Val > 0x300)
        ucAkey_Val = 4;
      else if(uiAdc_Val > 0x200)
        ucAkey_Val = 3;
      else if(uiAdc_Val > 0x60)
        ucAkey_Val = 2;
      else
        ucAkey_Val = 1;
    }
  }
  if(ucAkey_Val != ucAkey_Long)
	{
    ucAkey_Long = ucAkey_Val;
    ulAkey_Time = ulTick_ms;
    return ucAkey_Val;
	}
  return 0;
}

void Delay_AKEY(unsigned int ms)
{
  unsigned int i, j;

  for(i=0; i<ms; i++)
    for(j=0; j<7992; j++);			// SYSCLK = 72MHz
//  for(j=0; j<1598; j++);			// SYSCLK = 8MHz
}
#endif
