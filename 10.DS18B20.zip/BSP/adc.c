#include "adc.h"

void ADC1_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  ADC_InitTypeDef ADC_InitStruct;
  // ??GPIOB?ADC1   ����ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  // PB0-IN8ģ������
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStruct);
  // ��ʼ��ADC1 
  ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;  
  ADC_InitStruct.ADC_ScanConvMode = DISABLE;
  ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;//��������
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;//�������Ҷ���
  ADC_InitStruct.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStruct);
  // ͨ��8
  ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 1,
    ADC_SampleTime_1Cycles5);    
  // ͨ��16
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_16, 1,
    ADC_SampleTime_239Cycles5);
  ADC_TempSensorVrefintCmd(ENABLE);	
  ADC_AutoInjectedConvCmd(ADC1, ENABLE);
  // ����ADC1
  ADC_Cmd(ADC1, ENABLE);   
  // У׼ADC1
  ADC_StartCalibration(ADC1);
  while(ADC_GetCalibrationStatus(ADC1));
}

void ADC1_Init_AKEY(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  ADC_InitTypeDef ADC_InitStruct;
  // ����GPIOA��ADC1ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
  // PA5-IN5ģ������
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
  // ��ʼ��ADC1
  ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;  
  ADC_InitStruct.ADC_ScanConvMode = DISABLE;
  ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStruct.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStruct);
  // ����ͨ��5
  ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 1,
    ADC_SampleTime_1Cycles5);    
  ADC_InjectedChannelConfig(ADC1, ADC_Channel_4, 1,
    ADC_SampleTime_1Cycles5);						// 
  ADC_AutoInjectedConvCmd(ADC1, ENABLE);				// 
// ����ADC1
  ADC_Cmd(ADC1, ENABLE);   
  // У׼ADC1
  ADC_StartCalibration(ADC1);//ADCת��У׼
  while(ADC_GetCalibrationStatus(ADC1));
}

unsigned int ADC1_Conv(void)
{
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);//ʹ����������
  while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));//��ȡ��־״̬
  return ADC_GetConversionValue(ADC1);//��ȡADCת��ֵ
}

unsigned int ADC1_InjeConv(void)
{
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
  while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC));
  ADC_ClearFlag(ADC1, ADC_FLAG_JEOC);
  return ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
}


//#ifdef EXTEND     ����Ԥ����ָ��
//unsigned char AKEY_Read(void)
//{
//  unsigned char ucAkey_Val = 0;
//  unsigned int  uiAdc_Val = ADC1_Conv();

//  if(uiAdc_Val < 0xf00)				// ��������
//  { 
//    Delay_AKEY(100);
//    uiAdc_Val = ADC1_Conv();
//    if(uiAdc_Val < 0xf00)
//    { 
//      if(uiAdc_Val > 0xa00)       //3984
//        ucAkey_Val = 8;
//      else if(uiAdc_Val > 0x800)  //3507
//        ucAkey_Val = 7;
//      else if(uiAdc_Val > 0x680)  //2880
//        ucAkey_Val = 6;
//      else if(uiAdc_Val > 0x500)  //2367
//        ucAkey_Val = 5;
//      else if(uiAdc_Val > 0x300)  //1755
//        ucAkey_Val = 4;
//      else if(uiAdc_Val > 0x200)  //1149
//        ucAkey_Val = 3;
//      else if(uiAdc_Val > 0x60)   //534
//        ucAkey_Val = 2;
//      else
//        ucAkey_Val = 1;
//    }
//  }
//	if(ucAkey_Val != ucAkey_Long)
//	{
//    ucAkey_Long = ucAkey_Val;
//    ulAkey_Time = ulTick_ms;
//    return ucAkey_Val;
//	} 
//  return 0;
//}

//void Delay_AKEY(unsigned int ms)
//{
//  unsigned int i, j;

//  for(i=0; i<ms; i++)
//    for(j=0; j<7992; j++);			// SYSCLK = 72MHz
////  for(j=0; j<1598; j++);			// SYSCLK = 8MHz
//}
//#endif




/*

     ����ֵ    �м�ֵ    �м�ֵ��16������
s1    0
                267         0x10b
s2    534
                841         0x349
s3    1149
                1452        0x47d
s4    1755
                2061        0x80d
s5    2367
                2623        0xa3f
s6    2880
                3193        0xc79
s7    3507
                3745        0xea1
s8    3984
*/


unsigned char AKEY_Read(void)
{
  unsigned char ucAkey_Val = 0;
  unsigned int  uiAdc_Val = ADC1_Conv();

  if(uiAdc_Val < 6000)						
  {
    Delay_AKEY(100);							
    uiAdc_Val = ADC1_Conv();
    if(uiAdc_Val < 4095)					
    {
      if(uiAdc_Val > 3745)				
        ucAkey_Val = 8;
      else if(uiAdc_Val > 3193)		
        ucAkey_Val = 7;
      else if(uiAdc_Val > 2623)		
        ucAkey_Val = 6;
      else if(uiAdc_Val > 2061)		
        ucAkey_Val = 5;
      else if(uiAdc_Val > 1452)	
        ucAkey_Val = 4;
      else if(uiAdc_Val > 841)		
        ucAkey_Val = 3;
      else if(uiAdc_Val > 267)			
        ucAkey_Val = 2;
      else
        ucAkey_Val = 1;
			}
		
}
  return ucAkey_Val;
}




void Delay_AKEY(unsigned int ms)
{
  unsigned int i, j;

  for(i=0; i<ms; i++)
    for(j=0; j<7992; j++);			// SYSCLK = 72MHz
//  for(j=0; j<1598; j++);			// SYSCLK = 8MHz
}



















