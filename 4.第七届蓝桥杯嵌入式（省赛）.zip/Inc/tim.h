#include "stm32f10x.h"

void TIM1_OCInit(void);
void TIM2_ICInit(void);
unsigned char TIM2_Cap(unsigned int* puiTim_Val);

void TIM2_OCInit_072(void);
void TIM3_ICInit_072(void);
unsigned int  TIM3_Cap(void);

void TIM3_OCInit_081(void);

void TIM2_ICInit_082(void);
void TIM3_OCInit_082(void);

void TIM3_OCInit_091(void);

void TIM3_ICInit_102(void);
unsigned char TIM3_Pwm(void);
