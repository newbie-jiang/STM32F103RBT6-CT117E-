#include "stm32f10x.h"
#include "stdio.h"

void USART2_Init(unsigned long ulBaud);
unsigned char USART_SendChar(USART_TypeDef* USARTx, unsigned char ucChar);
void USART_SendString(USART_TypeDef* USARTx, unsigned char* pucStr);
//void USART2_IRQHandler(void);