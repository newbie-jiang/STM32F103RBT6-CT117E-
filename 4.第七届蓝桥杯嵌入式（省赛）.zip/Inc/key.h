#include "stm32f10x.h"
void KEY_Init(void);
unsigned char KEY_Scan(void);
void Delay_KEY(unsigned int ms);
void KEY_Proc(void);
void EXTIN_Init(void);