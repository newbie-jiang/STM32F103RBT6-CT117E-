#include "key.h"
#include "led.h"
#include "lcd.h"
#include "usart.h"


unsigned long ulTick_ms;                //SysTick_tim
unsigned char ucState=1 ,pucStr[21];    //lcd
unsigned char ucLed, ucLd2, ucLd3;      //led
unsigned char ucKey_Long;               //key
unsigned int delay=1000,pwmdelay=1000;  //tim
unsigned int  pwm=1000;                 //pwm_init
unsigned int  pwm_lcd=50;               //pwm_lcd_init

void led_all(void);
void led_left_right(void);
void KEY_Proc(void);
void LCD_Proc(void);

int main(void)
{
	
  SysTick_Config(72000);
	
  STM3210B_LCD_Init();
  LCD_Clear(Blue);
  LCD_SetBackColor(Blue);
  LCD_SetTextColor(White);
	
  KEY_Init();
  LED_Init();
  
  while(1)
  {
		pwm_lcd=pwm/20;//pwm����
    KEY_Proc();
    LCD_Proc();
		if(ucLd2){led_left_right();} 
		if(ucLd3){led_all();}
		LED_Disp(ucLed);
  }
}

void KEY_Proc(void)
{
  unsigned char ucKey_Val;

  ucKey_Val = KEY_Scan();
  if(ucKey_Val != ucKey_Long)
    ucKey_Long = ucKey_Val;
  else
    ucKey_Val = 0;

  switch(ucKey_Val)
  {
    case 1:												// B1: ���ü�
      if(ucState)
				ucState++;
			if(ucState==4)
				ucState=2;
			
      break;
    case 2:												// B2:�Ӱ���
      if(ucState==2)
       delay+=100;
			if(delay>2000)
				delay=1000;
			if(ucState==3)
			{
				pwm+=200;
				if(pwm>2000)
				pwm=1000;	
			}
      break;
    case 3:												// B3: ������
      if(ucState==2)
       delay-=100;
			if(delay<500)
				delay=1000;
			if(ucState==3)
			{
				pwm-=200;
				if(pwm<200)
				pwm=1000;	
			} 
      break;
   
  }
}


void LCD_Proc(void)
{
  if(ucState==1)										
  {
	 sprintf((char*)pucStr, "     please !!!      ");
   LCD_DisplayStringLine(Line4, pucStr);
	 ucLed=0x00;//Ĭ�Ϲر�����LED
	}
	
if(ucState==2)										
  {
	 sprintf((char*)pucStr, " LED_Delay: %1uMs        ", delay);
   LCD_DisplayStringLine(Line4, pucStr);
	 ucLd2=1;//LED״̬1��־
	 if(ucLd2==1)ucLd3=0;//ΪLED״̬����ͻ(������)
	}
if(ucState==3)														
  {
	 sprintf((char*)pucStr, "       PWM:%02u%%        ", pwm_lcd);
   if(ucState == 3) LCD_SetBackColor(Red);
   LCD_DisplayStringLine(Line4, pucStr);
   LCD_SetBackColor(Blue);
	 ucLd3=1;//LED״̬2��־
   if(ucLd3==1)ucLd2=0;//ΪLED״̬����ͻ(������)
	}
}


int number;
// SysTick�жϴ�������
void SysTick_Handler(void)
{
  ulTick_ms++;
	if(ucLd2){
if(ulTick_ms%delay == 0)
  {
    number++;
		if(number==14)	number=0;	//ΪLEDÿ��仯һ�����ı���
	}
}
	}



int led[14]={128,64,32,16,8,4,2,1,2,4,8,16,32,64}; //led����
void led_left_right()//LED״̬1
{
	ucLed=led[number];
}


//f=0.5hz   t=2s;   
void led_all(void) //LED״̬2
{
	if(ucLd3)
	{
	if(ulTick_ms%2000>=pwm)
	{ucLed=0x00;}
	else
	{ucLed=0xff;}
}
}





