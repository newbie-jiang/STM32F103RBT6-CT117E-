
#include "stm32f10x.h"
#include "stm32f10x_it.h"
#include "lcd.h"
#include "stdio.h"

uint32_t timingdelay;


uint16_t period;  
uint16_t duty ;   
uint8_t Flag ; 

void Time_Delay(uint16_t time);

void TIM3_PWM_Init(u16 arr,u16 psc);    //TIM3_CH3_CH4
void TIM4_Catch(u16 arr,u16 psc);      //TIM4_CH2����
void USART2_Init(unsigned long ulBaud);


uint16_t DutyCycle = 0; 
uint32_t Frequency = 0;

int main(void)
{
 
  
  SysTick_Config(SystemCoreClock / 1000); //1ms �ж�һ��
	TIM3_PWM_Init(1000-1,0); // 1��Ƶ ����  1/72000 Ƶ��72Khz
	TIM_SetCompare3(TIM3,400); //ռ�ձ� 60%
	TIM_SetCompare4(TIM3,800); //ռ�ձ� 80%
	
	TIM4_Catch(65535,0); //1��Ƶ ��72M Ƶ�ʲ��� 
	USART2_Init(9600);

  while (1)
  {    		
		  Time_Delay(500);
 		  if(!Flag)
			{
				printf("duty  = %.2f% % \r\n",((float)duty*100/period)); //ռ�ձ�
				printf("rate  = %.2fKHz\r\n\r\n",(float)(72000/period)); //Ƶ��
				Flag = 1;
			}
		
  }
}



u16 period = 0;
u16 duty  = 0;
u8 Flag = 1;  
void TIM4_IRQHandler(void)
{

	if(Flag)
	{
	 if (TIM_GetITStatus(TIM4, TIM_IT_CC2) != RESET)//���������¼�
		 {	
			duty = TIM_GetCapture1(TIM4)+1; 				//�ɼ�ռ�ձ�		
		  period	=	TIM_GetCapture2(TIM4)+1;     //�ɼ�����
		 }
		
		  Flag = 0;
	}	
		TIM_ClearITPendingBit(TIM4, TIM_IT_CC2|TIM_IT_Update); //����жϱ�־λ
}





void Time_Delay(uint16_t time)
{
	timingdelay = time;
	while(timingdelay !=0);
}
























