#include "stm32f10x.h"
#include "stdio.h"



void USART1_Init(unsigned long ulBaud);
void USART2_Init(unsigned long ulBaud);
unsigned char USART_SendChar(USART_TypeDef* USARTx, unsigned char ucChar);
void USART_SendString(USART_TypeDef* USARTx, unsigned char* pucStr);
unsigned char USART_ReceiveChar_NonBlocking(USART_TypeDef* USARTx);
void USART1_Init(unsigned long ulBaud);

