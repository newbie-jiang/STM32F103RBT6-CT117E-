#include "key.h"
// KEY�ӿڳ�ʼ��
void KEY_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  // ����GPIOA��GPIOBʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  // PA0��PA8��������(��λ״̬������ʡ��)
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  // PB1��PB2��������(��λ״̬������ʡ��)
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}
// KEYɨ��
unsigned char KEY_Scan(void)
{
  unsigned char ucKey_Val = 0;
  // �ж�B1��B2�Ƿ���
  if(~GPIO_ReadInputData(GPIOA) & 0x101)
  {
    Delay_KEY(10); // ��ʱ10ms����
    if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
      ucKey_Val = 1;
    if(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8))
      ucKey_Val = 2;
	}
  // �ж�B3��B4�Ƿ���
  else if(~GPIO_ReadInputData(GPIOB) & 6)
  {
    Delay_KEY(10);		// ��ʱ10ms����
    if(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1))
      ucKey_Val = 3;
    if(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_2))
      ucKey_Val = 4;
  }
  return ucKey_Val;
}

void Delay_KEY(unsigned int ms)
{
  unsigned int i, j;

  for(i=0; i<ms; i++)
    for(j=0; j<7992; j++);			// SYSCLK = 72MHz
  for(j=0; j<1598; j++);			// SYSCLK = 8MHz
}

//����PA0��PA8���ⲿ�ж�
//void GPIO_EXTI_source(void)
//{
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource8);
//}
////�����жϴ�����ʽ
//void Practice_GPIO_EXTI(void)
//{
//	EXTI_InitTypeDef EXTI_InitStructure;
//	EXTI_InitStructure.EXTI_Line=EXTI_Line0;
//	EXTI_Init(&EXTI_InitStructure);
//	
//}
//void EXTIN_Init(void)
//{
//	EXTI_InitTypeDef EXTI_InitStruct;
//	NVIC_InitTypeDef NVIC_InitStruct;
//	
//	KEY_Init();
//	
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource8);
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource1);
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource2);
//	
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
//	
//	EXTI_InitStruct.EXTI_Line=EXTI_Line0|EXTI_Line8|EXTI_Line1|EXTI_Line2;
//	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
//	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Falling;
//	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
//	EXTI_Init(&EXTI_InitStruct);
//	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//	NVIC_InitStruct.NVIC_IRQChannel=EXTI0_IRQn;
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority=0;
//	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_Init(&NVIC_InitStruct);
//	
//	NVIC_InitStruct.NVIC_IRQChannel=EXTI9_5_IRQn ;
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority=1;
//	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_Init(&NVIC_InitStruct);
//	
//	NVIC_InitStruct.NVIC_IRQChannel=EXTI1_IRQn;
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
//	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_Init(&NVIC_InitStruct);
//	
//	NVIC_InitStruct.NVIC_IRQChannel=EXTI2_IRQn ;
//	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;
//	NVIC_InitStruct.NVIC_IRQChannelSubPriority=3;
//	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_Init(&NVIC_InitStruct);
//}
