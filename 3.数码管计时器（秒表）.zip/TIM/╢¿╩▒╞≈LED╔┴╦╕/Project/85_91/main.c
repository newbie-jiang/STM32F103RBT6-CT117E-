
#include "stdio.h"
#include "seg.h"


unsigned int ucLCK;
unsigned int h=0,m=0,s=0,p=0;

void TIM2_Init(void);
void TIM2_NVIC(void);

int main(void)
{
  SysTick_Config(72000);			// ��ʱ1ms(HCLK = 72MHz)
	SEG_Init();
	//SEG_Disp(0,0,0,0);
	TIM2_Init();
	TIM2_NVIC();
	
	while(1)
		      {
	         SEG_Disp(h,m,s,p); 
					}
  
}

int num=0;
void TIM2_IRQHandler(void) 
{ 
  
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) != RESET)
	{
		
		 num++;
		 s++; 
		if(s==10)s=0;  
		 
	  if(num%10==0) m++;
		if(m==6)m=0;
		
	  if(num%60==0)h++;
		if(h==10)h=0;
		
	}
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
}



 void TIM2_NVIC(void)
 {
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����жϷ���
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;//����TIM2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//��ռ���ȼ�Ϊ0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;//��Ӧ���ȼ�Ϊ1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ж�Դ
  NVIC_Init(&NVIC_InitStructure);
 }



 void TIM2_Init(void) // 0.5S
{

  TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
 // RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  
  TIM_TimeBaseInitStruct.TIM_Prescaler = (2000-1);//Ԥ��Ƶϵ��    2000-1s  1000-0.5s  200-0.1s
	TIM_TimeBaseInitStruct.TIM_Period = (36000-1);//�Զ����ؼ�������ֵ
  TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;//����Ϊ���ϼ�����ʽ
  TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;//ʱ�ӷ�Ƶϵ��
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);
  TIM_ClearFlag(TIM2,TIM_FLAG_Update);//����ж�
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);//ʹ��TIM2�ĸ����ж�
  TIM_Cmd(TIM2, ENABLE);//ʹ��TIM2��ʱ��
}  



void SysTick_Handler(void)
{
	ucLCK++;
  if(ucLCK%1000>100)
		 p=5;
	if(ucLCK%1000<=100)
		 p=4;
	
	
	
	
//	if(ucLCK%1000==0)
//	{
//		s++; p++;
//		if(s==10)s=0;
//	}
//	
//	if(ucLCK%10000==0)
//	{
//		m++;
//		if(m==10)m=0;c
//	}
//	
//	
//	if(ucLCK%100000==0)
//	{
//		h++;
//		if(h==10)h=0;
//	}
	

	
}








