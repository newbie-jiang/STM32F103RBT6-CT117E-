#include "stm32f10x.h"

void LED_Init(void);
void LED_Disp(unsigned char ucLed);
void BUZ_Init(void);
void DIR_Init(void);
void LED_Proc(void);
