#include "led.h"
// LED�ӿڳ�ʼ��
void LED_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 |\
    GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 |\
    GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOC, &GPIO_InitStruct);
	
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
  GPIO_Init(GPIOD, &GPIO_InitStruct);
}
// LED��ʾ
// ��ڲ�����ucLed-8λ��ʾ���ƣ�1-����0-��
void LED_Disp(unsigned char ucLed)
{
  GPIO_Write(GPIOC, ~ucLed << 8);
  GPIO_SetBits(GPIOD,GPIO_Pin_2);
  GPIO_ResetBits(GPIOD,GPIO_Pin_2);
}
// �������ӿڳ�ʼ��
void BUZ_Init(void)
{ 
  GPIO_InitTypeDef GPIO_InitStruct;
  // ����AFIO��GPIOBʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  // ��������ӳ�䣨��ֹJTRST���ܣ�
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_NoJTRST, ENABLE);
  // PB4�������
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void DIR_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  // PA4-PA5??????
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
}
