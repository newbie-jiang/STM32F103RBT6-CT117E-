#include "seg.h"
// SEG?????
void SEG_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  // ??GPIOA??
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  // PA1-SER?PA2-RCK?PA3-SCK??????
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
}
// SEG??
// ????:data1?data2?data3-3?????,dot-3????
void SEG_Disp(unsigned char ucData1, unsigned char ucData2,
  unsigned char ucData3, unsigned char ucDot)
{
  unsigned char i;
  unsigned char code[17]={0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07,
    0x7f, 0x6f, 0x77, 0x7c, 0x39, 0x5e, 0x79, 0x71, 0x00};
  unsigned long ulData = (code[ucData3] << 16) + (code[ucData2] << 8)
    + code[ucData1];

  ulData += (ucDot&1)<<23;
  ulData += (ucDot&2)<<14;
  ulData += (ucDot&4)<<5;

  for(i=0; i<24; i++)
  {
    if(ulData & 0x800000)						// ???????
      GPIO_SetBits(GPIOA, GPIO_Pin_1);			// PA1(SER)=1
    else
      GPIO_ResetBits(GPIOA, GPIO_Pin_1);		// PA1(SER)=0
    ulData <<= 1;
    GPIO_SetBits(GPIOA, GPIO_Pin_3);			// PA3(SCK)=1
    GPIO_ResetBits(GPIOA, GPIO_Pin_3);			// PA3(SCK)=0
  }
  GPIO_SetBits(GPIOA, GPIO_Pin_2);				// PA2(RCK)=1
  GPIO_ResetBits(GPIOA, GPIO_Pin_2);			// PA2(RCK)=0
}
