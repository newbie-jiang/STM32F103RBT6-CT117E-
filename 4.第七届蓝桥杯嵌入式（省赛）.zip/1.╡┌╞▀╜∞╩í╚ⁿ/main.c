#include "key.h"
#include "led.h"
#include "lcd.h"
#include "usart.h"
#include "i2c.h"
#include "adc.h"

unsigned int uiAdc_Val;
unsigned char ucHeight, ucLevel, ucLevel1;
unsigned char ucState, pucStr[21], pucTh[3], pucRcv[1];
unsigned char ucLed, ucLd2, ucLd3, ucNum = 10;
unsigned char ucSec, ucSec1, ucKey_Long;
unsigned long ulTick_ms;

void KEY_Proc(void);
void LCD_Proc(void);
void ADC_Proc(void);
void UART_Proc(void);

int main(void)
{
  SysTick_Config(72000);
  KEY_Init();
  LED_Init();

  STM3210B_LCD_Init();
  LCD_Clear(Blue);
  LCD_SetBackColor(Blue);
  LCD_SetTextColor(White);

  USART2_Init(9600);
  i2c_init();
  ADC1_Init();
	
  i2c_read(pucTh, 0, 3);
  if(pucTh[0] > 100) pucTh[0] = 10;
  if(pucTh[1] > 100) pucTh[0] = 20;
  if(pucTh[2] > 100) pucTh[0] = 30;
	
  while(1)
  {
    KEY_Proc();
    LCD_Proc();
    ADC_Proc();
    UART_Proc();
  }
}

void KEY_Proc(void)
{
  unsigned char ucKey_Val;

  ucKey_Val = KEY_Scan();
  if(ucKey_Val != ucKey_Long)
    ucKey_Long = ucKey_Val;
  else
    ucKey_Val = 0;

  switch(ucKey_Val)
  {
    case 1:												// B1: ���ü�
      if(!ucState)
        ucState = 1;
      else
      {
        if(pucTh[0] < pucTh[1] && pucTh[1] < pucTh[2])
        {
          LCD_DisplayStringLine(Line3, (u8*)"                    ");

          i2c_write(pucTh, 0, 3);							// ������ֵ
          ucState = 0;
        }
        else
        {
          LCD_SetTextColor(Red);
          LCD_DisplayStringLine(Line3, (u8*)"  Threshold Error   ");
          LCD_SetTextColor(White);
        }
      }
      break;
    case 2:												// B2: �л���
      if(ucState)
        if(++ucState == 4)
          ucState = 1;
      break;
    case 3:												// B3: ��ֵ��
      if(ucState)
        if(pucTh[ucState-1] < 95)
          pucTh[ucState-1] += 5;
      break;
    case 4:												// B4: ��ֵ��
      if(ucState)
        if(pucTh[ucState-1] > 5)
          pucTh[ucState-1] -= 5;
  }
}

void LCD_Proc(void)
{
  float temp;

  if(!ucState)											// Һλ���
  {
    LCD_DisplayStringLine(Line1, (u8*)"    Liquid Level    ");

    sprintf((char*)pucStr, "    Height:%03ucm    ", ucHeight);
    LCD_DisplayStringLine(Line4, pucStr);

    temp = (float)uiAdc_Val*3.3/4095;
    sprintf((char*)pucStr, "    VR37:  %4.2fV    ", temp);
    LCD_DisplayStringLine(Line6, pucStr);

    sprintf((char*)pucStr, "    Level: %1u        ", ucLevel);
    LCD_DisplayStringLine(Line8, pucStr);
  }
  else													// ��ֵ����
  {
    LCD_DisplayStringLine(Line1, (u8*)"  Threshold Setup   ");

    sprintf((char*)pucStr, "  Threshold 1:%02ucm  ", pucTh[0]);
    if(ucState == 1) LCD_SetBackColor(Red);
    LCD_DisplayStringLine(Line4, pucStr);
    LCD_SetBackColor(Blue);

    sprintf((char*)pucStr, "  Threshold 2:%02ucm  ", pucTh[1]);
    if(ucState == 2) LCD_SetBackColor(Red);
    LCD_DisplayStringLine(Line6, pucStr);
    LCD_SetBackColor(Blue);

    sprintf((char*)pucStr, "  Threshold 3:%02ucm  ", pucTh[2]);
    if(ucState == 3) LCD_SetBackColor(Red);
    LCD_DisplayStringLine(Line8, pucStr);
    LCD_SetBackColor(Blue);
  }
}

void ADC_Proc(void)
{
  if(!ucState && ucSec != ucSec1)
  {
    ucSec1 = ucSec;

    uiAdc_Val = ADC1_Conv();							// ��ȡת��ֵ
    ucHeight = uiAdc_Val*100/4095;						// ����Һλ�߶�

    if(ucHeight < pucTh[0])
      ucLevel = 0;
    else if(ucHeight < pucTh[1])
      ucLevel = 1;
    else if(ucHeight < pucTh[2])
      ucLevel = 2;
    else
      ucLevel = 3;

    if(ucLevel != ucLevel1)
    {
      if(ucLevel > ucLevel1)								// Һλ����
        printf("A:H%02u+L%1u+U\r\n", ucHeight, ucLevel);
      else												// Һλ����
        printf("A:H%02u+L%1u+D\r\n", ucHeight, ucLevel);

      ucLevel1 = ucLevel;
      ucLd2 = 1;											// �ȼ��ı�
    }
  }
}

void UART_Proc(void)
{
  if(pucRcv[0] == 'C')
    printf("C:H%02u+L%1u\r\n", ucHeight, ucLevel);
  if(pucRcv[0] == 'S')
    printf("S:TL%02u+TM%02u+TH%02u\r\n", pucTh[0], pucTh[1], pucTh[2]);
  if(pucRcv[0] == 'C' || pucRcv[0] == 'S')
    ucLd3 = 1;											// ���ڲ�ѯ
  pucRcv[0] = 0;
}
// SysTick�жϴ�������
void SysTick_Handler(void)
{
  ulTick_ms++;

  if(ulTick_ms%1000 == 0)
  {
    ucSec++;
    ucLed ^= 1;											// LD1��˸
  }

  if(ucLd2)												// �ȼ��ı�
  {
    if(ulTick_ms%200 == 0)
    {
      if(ucNum--)
        ucLed ^= 2;										// LD2��˸5��
      else
      {
        ucLd2 = 0;
        ucNum = 10;
      }
    }
  }

  if(ucLd3)												// ���ڲ�ѯ
  {
    if(ulTick_ms%200 == 0)
    {
      if(ucNum--)
        ucLed ^= 4;										// LD3��˸5��
      else
      {
        ucLd3 = 0;
        ucNum = 10;
      }
    }
  }
  LED_Disp(ucLed);
}
// USART2�жϴ�������
void USART2_IRQHandler(void)
{
	pucRcv[0] = USART_ReceiveData(USART2);
}
