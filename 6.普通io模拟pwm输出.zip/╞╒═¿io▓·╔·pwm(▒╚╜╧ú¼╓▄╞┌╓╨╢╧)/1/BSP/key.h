#include "stm32f10x.h"

extern unsigned char ucKey_Long;
extern unsigned long ulTick_ms, ulKey_Time;

void KEY_Init(void);
unsigned char KEY_Scan(void);
void Delay_KEY(unsigned int ms);
