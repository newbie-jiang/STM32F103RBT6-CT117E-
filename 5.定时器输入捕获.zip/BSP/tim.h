#include "stm32f10x.h"

void TIM1_OCInit(void);
void TIM2_ICInit(void);
unsigned char TIM2_Cap(unsigned int* puiTim_Val);

void TIM2_OCInit_7272(void);
void TIM3_ICInit_7272(void);
unsigned int  TIM3_Cap(void);

void TIM3_OCInit_7381(void);

void TIM2_ICInit_7482(void);
void TIM3_OCInit_7482(void);

void TIM3_OCInit_7591(void);




void PWM_TIM4_IO_1234(void);
void TIM4_Config1234(uint16_t duty1, uint16_t duty2, uint16_t duty3, uint16_t duty4);

void TIM3_PWM_Init(u16 arr,u16 psc);
void TIM4_Catch(u16 arr,u16 psc); 

