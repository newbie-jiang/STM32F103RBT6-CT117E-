#include "stm32f10x.h"

void ADC1_Init(void);
unsigned int ADC1_Conv(void);
unsigned int ADC1_InjeConv(void);

void ADC1_Init_AKEY(void);
#ifdef EXTEND
extern unsigned char ucAkey_Long;
extern unsigned long ulTick_ms, ulAkey_Time;

unsigned char AKEY_Read(void);
void Delay_AKEY(unsigned int ms);
#endif
