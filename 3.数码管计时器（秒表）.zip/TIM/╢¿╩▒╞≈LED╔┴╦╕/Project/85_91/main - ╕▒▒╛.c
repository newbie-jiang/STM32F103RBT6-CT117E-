#include "led.h"
#include "key.h"
#include "lcd.h"
#include "stdio.h"
#include "at24c02.h"
#include "tim.h"

unsigned char ucLed = 0;
unsigned char ucKey_Short, ucKey_Long;
unsigned char ucState = 0, ucNo = 1;
unsigned char ucStr[21];
unsigned char ucTime, ucHour, ucMin, ucSec;
unsigned long ulTick_ms, ulSec, ulKey_Time;

void KEY_Proc(void);
void LCD_Proc(void);
void B3_Proc(void);

int main(void)
{
  SysTick_Config(72000);
  KEY_Init();
  LED_Init();
  STM3210B_LCD_Init();
  LCD_Clear(Blue);
  LCD_SetBackColor(Blue);
  LCD_SetTextColor(White);
  i2c_init();
//  TIM3_Init();
	
  i2c_read(ucStr, 0, 3);
  ucHour = ucStr[0];
  ucMin  = ucStr[1];
  ucSec  = ucStr[2];	
	
  while(1)
  {
    KEY_Proc();
    LCD_Proc();
  }
}

void KEY_Proc(void)
{
  unsigned char ucKey_Val;

  ucKey_Val = KEY_Scan();
  ucKey_Short = ucKey_Val & (ucKey_Val ^ ucKey_Long);
  ucKey_Long = ucKey_Val;

  if(ucKey_Short)  ulKey_Time = ulTick_ms;
	
  switch(ucKey_Short)
  {
    case 1:							// B1: ???????
    {
      if(ucState == 0)
      {
        if(++ucNo == 6)
          ucNo = 1;
        i2c_read(ucStr, 3*(ucNo - 1), 3);
        ucHour = ucStr[0];
        ucMin  = ucStr[1];
        ucSec  = ucStr[2];
      }
      break;
    }
    case 2:							// B2: ???????
    {
      if(ucState == 0)
      {
        ucState = 1;
        ucTime = 1;
      }
      else if(ucState == 1)
        if(++ucTime == 4)
          ucTime = 1;
      break;
    }
    case 4:							// B3: ???
    {
      B3_Proc();
      break;
	  }
    case 8:							// B4: ???
    {
      ucTime = 0;
      if(ucState == 0 || ucState == 1)
        ucState = 2;				// ??
      else if(ucState == 2)
        ucState = 3;				// ??
      else if(ucState == 3)
        ucState = 2;

			if(ucState == 2)
				ulSec = (long)ucHour*3600 + ucMin*60 + ucSec;
    }
  }
	
  if(ulTick_ms-ulKey_Time > 800)
  {
    switch(ucKey_Long)
    {
      case 2:
			{
				if(ucState == 1)				// ????
        {
          ucState = 0;
          ucTime = 0;
          ucStr[0] = ucHour;
          ucStr[1] = ucMin;
          ucStr[2] = ucSec;
          i2c_write(ucStr, 3*(ucNo - 1), 3);
        }
				break;
      }
			case 4:
			{
        B3_Proc();
        break;
			}
			case 8:
			{
        if(ucState == 2 || ucState == 3)
          ucState = 0;
			}
		}
  }
}

void B3_Proc(void)
{
  switch(ucTime)
  {
    case 1:
    {
      if(++ucHour > 23)
        ucHour = 0;
			break;
    }
    case 2:
    {
      if(++ucMin > 59)
        ucMin = 0;
			break;
    }
    case 3:
    {
      if(++ucSec > 59)
        ucSec = 0;
    }
  }
}

void LCD_Proc(void)
{
  sprintf((char*)ucStr, "        No.%1u", ucNo);
  LCD_DisplayStringLine(Line3, ucStr);

  if(ucTime==1) LCD_SetBackColor(Red);
  LCD_DisplayChar(Line5, 224, ucHour/10+0x30);
  LCD_DisplayChar(Line5, 208, ucHour%10+0x30);
  LCD_SetBackColor(Blue);
  LCD_DisplayChar(Line5, 192, ':');

  if(ucTime==2) LCD_SetBackColor(Red);
  LCD_DisplayChar(Line5, 176, ucMin/10+0x30);
  LCD_DisplayChar(Line5, 160, ucMin%10+0x30);
  LCD_SetBackColor(Blue);
  LCD_DisplayChar(Line5, 144, ':');

  if(ucTime==3) LCD_SetBackColor(Red);
  LCD_DisplayChar(Line5, 128, ucSec/10+0x30);
  LCD_DisplayChar(Line5, 112, ucSec%10+0x30);
  LCD_SetBackColor(Blue);

  switch(ucState)
	{
    case 0:
      sprintf((char*)ucStr, "      Standby.");
      LCD_DisplayStringLine(Line7, ucStr);
      break;
    case 1:
      sprintf((char*)ucStr, "      Setting.");
      LCD_DisplayStringLine(Line7, ucStr);
      break;
    case 2:
      sprintf((char*)ucStr, "      Running.");
      LCD_DisplayStringLine(Line7, ucStr);
      break;
    case 3:
      sprintf((char*)ucStr, "       Pause. ");
      LCD_DisplayStringLine(Line7, ucStr);
  }
}
// SysTick??????
void SysTick_Handler(void)
{
  ulTick_ms++;
  if(ucState == 2)
  {
    if(ulTick_ms%500 == 0)
    {
      ucLed ^= 1;
      LED_Control(ucLed);
    }
	  if(ulTick_ms%1000 == 0)
		{
      if(ulSec--)
			{
			  ucHour = ulSec / 3600;
			  ucMin  = ulSec % 3600 / 60;
			  ucSec  = ulSec % 3600 % 60;
      }
			else
			{
			  ucState = 0;
        LED_Control(0);
      }
		}
	}
}
