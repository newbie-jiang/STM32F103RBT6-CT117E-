#include "key.h"
#include "led.h"
#include "lcd.h"
#include "stdio.h"
#include "usart.h"
#include "stm32f10x_exti.h"


void LCD_Proc(void);
void LED_Proc(void);
void Key_Init(void);
void LED_Control(uint16_t LED,uint8_t LED_Status);
void USART1_Init(unsigned long ulBaud);


uint32_t TimingDelay = 1;
unsigned char ucSec,ucLed=1;
unsigned long ulTick_ms;
int col_flag=0;
unsigned int i;


int main(void)
{
  SysTick_Config(72000);			// ��ʱ1ms(HCLK = 72MHz)
  Key_Init();
  LED_Init();
  BUZ_Init();
  STM3210B_LCD_Init();				//LCD�ĳ�ʼ��
	
  LCD_Clear(Cyan);				        //����������ɫ
	LCD_SetTextColor(White);		    //������ɫ
  LCD_SetBackColor(Cyan);	  	    //���屳����ɫ
   
  LED_Control(LEDALL,0);//��������LED��Ĭ�Ϲرգ�0�رգ�1�򿪣�
	USART1_Init(9600);
	
	  USART_SendString(USART1,"����������ָ�\r\n");	
		USART_SendString(USART1,"   ����0��LED����\r\n");	
		USART_SendString(USART1,"   ����1��LED����\r\n");	
		USART_SendString(USART1,"   ����2���򿪷�����\r\n");	
	  USART_SendString(USART1,"   ����3���رշ�����\r\n\r\n");	
	      
  while(1)
  { 
	 LCD_Proc();
	 LED_Proc();
	}
  }
	
  
void LED_Proc(void)
{
	switch(col_flag)
	{
		case 1:
		  if(ulTick_ms > 300)      //0.3S��ʱ
		  {
			ulTick_ms = 0;
			  
			ucLed >>= 1;
			if(ucLed == 0) 
				ucLed =0x80;           //LED���ƺ���
			LED_Disp(ucLed);
		  }
		  break;
			
			
		case 2:
		  if(ulTick_ms > 300)      //0.3S��ʱ
		  {
			ulTick_ms = 0;
			  
			LED_Disp(ucLed);
			ucLed <<= 1;             //LED���ƺ���
			if(ucLed ==0)
				ucLed = 1;
		  }
		  break;
			
			
		case 3:
			LED_Control(LEDALL,0);
			GPIO_ResetBits(GPIOB,GPIO_Pin_4);//�򿪷�����
		  break;
		
		
		case 4:
			LED_Control(LEDALL,0);
			GPIO_SetBits(GPIOB,GPIO_Pin_4);
		
	}
	
}

/*************************************

LCD������ʾ��Ҫ���ֿ⣬��fonts.h�ļ���

*************************************/
//LCD������ʾ
void LCD_Proc(void)
{
    LCD_DisplayStringLine(Line1,"      19");
	  LCD_DisplayproHZ(Line1, 4, 0);
	  LCD_DisplayproHZ(Line1, 5, 1);
	  LCD_DisplayproHZ(Line1, 6, 2);   //Ƕ��ʽ
	
	if(col_flag==1)
		LCD_SetBackColor(Blue);
		LCD_DisplayStringLine(Line3,"    1. LED");
    LCD_DisplayproHZ(Line3, 5, 4);
	  LCD_DisplayproHZ(Line3, 6, 5);   //����
		LCD_SetBackColor(Cyan);

	if(col_flag==2)
		LCD_SetBackColor(Blue);
		
	
	  LCD_DisplayStringLine(Line5,"    2. LED");
	  LCD_DisplayproHZ(Line5, 5, 3);
	  LCD_DisplayproHZ(Line5, 6, 5);  //����
		LCD_SetBackColor(Cyan);

	if(col_flag==3)
	  LCD_SetBackColor(Blue);
	  LCD_DisplayStringLine(Line7,"    3.");
    LCD_DisplayproHZ(Line7, 3, 6);
    LCD_DisplayproHZ(Line7, 4, 7);
	  LCD_DisplayproHZ(Line7, 5, 8);
	  LCD_DisplayproHZ(Line7, 6, 9);  //��������
		LCD_SetBackColor(Cyan);
	if(col_flag==4)
		LCD_SetBackColor(Blue);
		LCD_DisplayStringLine(Line9,"    4.");
		LCD_DisplayproHZ(Line9, 3, 6);
		LCD_DisplayproHZ(Line9, 4, 7);
	  LCD_DisplayproHZ(Line9, 5, 8);
	  LCD_DisplayproHZ(Line9, 6, 10); //��������
		LCD_SetBackColor(Cyan);
	
 

	
}


//�����ж�
void Key_Init(void)
{
	EXTI_InitTypeDef   EXTI_InitStructure;//����ṹ��
	GPIO_InitTypeDef   GPIO_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure; 	

	//ʱ������
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  /* PA0��PA8��������*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure); 
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0|GPIO_PinSource8);
  /* PB1��PB2��������*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure); 
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1|GPIO_PinSource2);
	
	
   GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);//��PA0�ж�����
 	 EXTI_ClearITPendingBit(EXTI_Line0);//����жϱ�־
 	 GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource8);//��PA8�ж�����
	 EXTI_ClearITPendingBit(EXTI_Line8); 
	 GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource1);//��PB1�ж�����
	 EXTI_ClearITPendingBit(EXTI_Line1);
	 GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource2);//��PB2�ж�����
	 EXTI_ClearITPendingBit(EXTI_Line2);
	
  	EXTI_InitStructure.EXTI_Line = EXTI_Line0|EXTI_Line8|EXTI_Line1|EXTI_Line2;//ѡ���ж���0,8,2,1
  	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//�����ж�����
  	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;//�½��ش���  
  	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//ʹ���ж���
  	EXTI_Init(&EXTI_InitStructure);


    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�ж����ȼ�����
		
		
  //PA0 
  	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;//ʹ�ܰ������ڵ��ⲿ�ж�ͨ��
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//��ռ���ȼ�
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;//�����ȼ�
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;//ʹ���ⲿ�ж�ͨ��
  	NVIC_Init(&NVIC_InitStructure);

	//PA8
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);

	//  PB1 
  	NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority =2;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);

	// PB2
  	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);

}




//�жϷ�����
void EXTI0_IRQHandler(void)   //PA0
{  
	 for(i=0x5ffff; i>0; i--);//��ʱ
	
	if(EXTI_GetFlagStatus(EXTI_Line0)!=RESET)
	{
		EXTI_ClearFlag(EXTI_Line0);
		
				 col_flag++;
			if(col_flag>4)
				 col_flag=1;
			
	}
}

void EXTI9_5_IRQHandler(void)    //PA8
{   
	for(i=0x5ffff; i>0; i--);//��ʱ
	if(EXTI_GetFlagStatus(EXTI_Line8)!=RESET)
	{
		EXTI_ClearFlag(EXTI_Line8);
			   col_flag--;
			if(col_flag<1)
				 col_flag=4;
			
	}
}


void EXTI1_IRQHandler(void)  //PB1
{  
	 for(i=0x5ffff; i>0; i--);//��ʱ
	
	if(EXTI_GetFlagStatus(EXTI_Line1)!=RESET)
	{
		EXTI_ClearFlag(EXTI_Line1);
		
				 col_flag++;
			if(col_flag>4)
				 col_flag=1;
			
	}
}



void EXTI2_IRQHandler(void)  //PB2
{   for(i=0x5ffff; i>0; i--);//��ʱ
	if(EXTI_GetFlagStatus(EXTI_Line2)!=RESET)
	{
		EXTI_ClearFlag(EXTI_Line2);
			   col_flag--;
			if(col_flag<1)
				 col_flag=4;
			
	}
}

//�����жϷ�����
void USART1_IRQHandler(void)    
{
  uint8_t temp;
  if(USART_GetFlagStatus(USART1,USART_IT_RXNE)!=0)
  { 
		temp=USART_ReceiveData(USART1);
		USART_SendData(USART1,temp);
		
		switch(temp)
		{
			
			case'0':
				col_flag=1;
			USART_SendString(USART1,":LED�����Ѵ�\r\n\r\n");
       
		
			  break;
				
			case'1':
				col_flag = 2;	
				USART_SendString(USART1,"��LED�����Ѵ�\r\n\r\n");		
			  
				break;
			
			case'2':
				//col_flag = 3;	//̫����,ʵ���Լ���
				USART_SendString(USART1,"���������Ѵ�\r\n\r\n");	
        
       	break;
			
			case'3':
				col_flag = 4;
				USART_SendString(USART1,"���������ѹر�\r\n\r\n");	
        break;
		
	
		}
		
  }

}





void SysTick_Handler(void)
{
  ulTick_ms++;
  if(ulTick_ms%1000 == 0) ucSec+=0;          
}














